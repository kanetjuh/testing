const express = require('express');
const router = express.Router();
const { db } = require('../../handlers/db');
const axios = require('axios');

const { loadPlugins } = require('../loadPls'); // Correct import
const path = require('path');

function formatDownloads(downloads) {
    if (downloads >= 1000000) {
        return (downloads / 1000000).toFixed(1) + 'm';
    } else if (downloads >= 1000) {
        return (downloads / 1000).toFixed(1) + 'k';
    } else {
        return downloads.toString();
    }
}

function filterResources(resources, searchText) {
    if (!searchText) return resources;

    searchText = searchText.toLowerCase();
    return resources.filter(resource =>
        resource.name.toLowerCase().includes(searchText) ||
        (resource.author && resource.author.name.toLowerCase().includes(searchText))
    );
}

router.get('/instance/:id/installer', async (req, res) => {
    const plugins = await loadPlugins(path.join(__dirname, '../../plugins'));
    const { id } = req.params;
    const { search = '', page = 1, size = 20 } = req.query; // Default to page 1 and size 20
    const allPluginData = Object.values(plugins).map(plugin => plugin.config);

    try {
        const response = await axios.get(`https://api.spiget.org/v2/resources?size=1000`);
        const resources = response.data;

        const filteredResources = filterResources(resources, search);
        const paginatedResources = filteredResources.slice((page - 1) * size, page * size);

        res.render('pluginsinstaller_index', {
            user: req.user,
            req,
            resources: paginatedResources,
            name: await db.get('name') || 'Skyport',
            logo: await db.get('logo') || false,
            addons: {
                plugins: allPluginData
            },
            formatDownloads,
            total: filteredResources.length,
            page: parseInt(page),
            size: parseInt(size)
        });
    } catch (error) {
        console.error('Error fetching resources:', error);
        res.status(500).send('Error fetching resources');
    }
});

module.exports = router;
